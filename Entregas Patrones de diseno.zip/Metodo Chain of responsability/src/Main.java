// Interfaz Handler
abstract class Manejador {
    protected Manejador siguiente;

    public void setSiguiente(Manejador siguiente) {
        this.siguiente = siguiente;
    }

    public abstract void manejar();
}

// Handler concreto: Obtener Placa
class ObtenerPlaca extends Manejador {
    public void manejar() {
        System.out.println("Obteniendo la placa...");
        if (siguiente != null) siguiente.manejar();
    }
}

// Handler concreto: Soldar
class SoldarPlaca extends Manejador {
    public void manejar() {
        System.out.println("Soldando la placa...");
        if (siguiente != null) siguiente.manejar();
    }
}

// Handler concreto: Enviar
class EnviarPlaca extends Manejador {
    public void manejar() {
        System.out.println("Enviando la placa...");
    }
}

// Programa principal
public class Main {
    public static void main(String[] args) {
        // Crear manejadores
        Manejador obtener = new ObtenerPlaca();
        Manejador soldar = new SoldarPlaca();
        Manejador enviar = new EnviarPlaca();

        // Formar la cadena
        obtener.setSiguiente(soldar);
        soldar.setSiguiente(enviar);

        // Iniciar el proceso
        obtener.manejar();
    }
}
