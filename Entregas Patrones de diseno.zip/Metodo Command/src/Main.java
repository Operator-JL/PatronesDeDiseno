// Interfaz Command
interface Comando {
    void ejecutar();
}

// Receptor: el Cubo de Rubik
class CuboRubik {
    void girarDerecha() {
        System.out.println("Girando la cara derecha del cubo.");
    }

    void girarIzquierda() {
        System.out.println("Girando la cara izquierda del cubo.");
    }
}

// Comando concreto para girar derecha
class GirarDerecha implements Comando {
    private CuboRubik cubo;

    public GirarDerecha(CuboRubik cubo) {
        this.cubo = cubo;
    }

    public void ejecutar() {
        cubo.girarDerecha();
    }
}

// Comando concreto para girar izquierda
class GirarIzquierda implements Comando {
    private CuboRubik cubo;

    public GirarIzquierda(CuboRubik cubo) {
        this.cubo = cubo;
    }

    public void ejecutar() {
        cubo.girarIzquierda();
    }
}

// Clase principal
public class Main {
    public static void main(String[] args) {
        CuboRubik cubo = new CuboRubik();

        Comando derecha = new GirarDerecha(cubo);
        Comando izquierda = new GirarIzquierda(cubo);

        derecha.ejecutar();    // Ejecuta girar derecha
        izquierda.ejecutar();  // Ejecuta girar izquierda
    }
}
