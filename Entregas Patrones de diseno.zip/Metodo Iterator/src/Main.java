// Interfaz Iterator
interface Iterador {
    boolean tieneSiguiente();
    char siguiente();
}

// Clase concreta que implementa el Iterator
class IteradorString implements Iterador {
    private String texto;
    private int posicion = 0;

    public IteradorString(String texto) {
        this.texto = texto;
    }

    public boolean tieneSiguiente() {
        return posicion < texto.length();
    }

    public char siguiente() {
        return texto.charAt(posicion++);
    }
}

// Programa principal
public class Main {
    public static void main(String[] args) {
        Iterador iterador = new IteradorString("Hola");

        while (iterador.tieneSiguiente()) {
            System.out.println(iterador.siguiente());
        }
    }
}
