// Interfaz Mediador
interface Mediador {
    void manejarPaso(Vehiculo vehiculo);
}

// Mediador concreto: Policia
class Policia implements Mediador {
    @Override
    public void manejarPaso(Vehiculo vehiculo) {
        System.out.println("Policia permite pasar a " + vehiculo.getNombre());
        vehiculo.cruzar();
    }
}

// Clase Vehiculo
class Vehiculo {
    private String nombre;
    private Mediador policia;

    public Vehiculo(String nombre, Mediador policia) {
        this.nombre = nombre;
        this.policia = policia;
    }

    public String getNombre() {
        return nombre;
    }

    public void pedirPaso() {
        policia.manejarPaso(this);
    }

    public void cruzar() {
        System.out.println(nombre + " esta cruzando la interseccion.");
    }
}

// Clase principal
public class Main {
    public static void main(String[] args) {
        Mediador policia = new Policia();
        Vehiculo carro = new Vehiculo("Carro Rojo", policia);
        Vehiculo moto = new Vehiculo("Moto Azul", policia);

        carro.pedirPaso();
        moto.pedirPaso();
    }
}
