import java.util.Stack;

// Originador
class Dibujo {
    String contenido = "";

    Memento guardar() {
        return new Memento(contenido);
    }

    void restaurar(Memento m) {
        contenido = m.estado;
    }
}

// Memento
class Memento {
    String estado;

    Memento(String estado) {
        this.estado = estado;
    }
}

// Caretaker
class Historial {
    Stack<Memento> historial = new Stack<>();

    void guardar(Dibujo d) {
        historial.push(d.guardar());
    }

    void deshacer(Dibujo d) {
        if (!historial.isEmpty()) {
            d.restaurar(historial.pop());
        }
    }
}

// Programa principal
public class Main {
    public static void main(String[] args) {
        Dibujo dibujo = new Dibujo();
        Historial historial = new Historial();

        dibujo.contenido = "Linea";
        historial.guardar(dibujo);

        dibujo.contenido = "Linea y Circulo";
        historial.guardar(dibujo);

        dibujo.contenido = "Linea, Circulo y Cuadrado";
        historial.guardar(dibujo);

        System.out.println("Dibujo actual: " + dibujo.contenido);

        historial.deshacer(dibujo);
        System.out.println("Despues de deshacer: " + dibujo.contenido);

        historial.deshacer(dibujo);
        System.out.println("Despues de otro deshacer: " + dibujo.contenido);
    }
}
