// Clase contexto que usa una estrategia de precio
public class CalculadoraPrecio {
    private EstrategiaPrecio estrategia;

    public CalculadoraPrecio(EstrategiaPrecio estrategia) {
        this.estrategia = estrategia;
    }

    public void setEstrategia(EstrategiaPrecio estrategia) {
        this.estrategia = estrategia;
    }

    public double calcularPrecio(CategoriaComponentes pc) {
        return estrategia.calcular(pc);
    }
}
