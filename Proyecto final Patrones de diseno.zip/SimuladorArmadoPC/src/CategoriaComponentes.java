// Clase compuesta que agrupa componentes como categoria
import java.util.ArrayList;
import java.util.List;

public class CategoriaComponentes implements ComponentePC {
    private String nombre;
    private List<ComponentePC> componentes = new ArrayList<>();

    public CategoriaComponentes(String nombre) {
        this.nombre = nombre;
    }

    public void agregar(ComponentePC componente) {
        componentes.add(componente);
    }

    @Override
    public void mostrar() {
        System.out.println("> " + nombre + ":");
        for (ComponentePC c : componentes) {
            c.mostrar();
        }
    }

    @Override
    public double obtenerPrecio() {
        double total = 0;
        for (ComponentePC c : componentes) {
            total += c.obtenerPrecio();
        }
        return total;
    }

    @Override
    public String toString() {
        return nombre + " - Total: $" + obtenerPrecio();
    }
}
