// Interfaz base para todos los componentes de la PC
public interface ComponentePC {
    void mostrar();              // Muestra el nombre y precio
    double obtenerPrecio();      // Devuelve el precio
}
