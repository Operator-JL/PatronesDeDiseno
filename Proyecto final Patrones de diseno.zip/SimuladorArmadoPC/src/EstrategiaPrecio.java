// Interfaz para definir estrategias de calculo de precio
public interface EstrategiaPrecio {
    double calcular(CategoriaComponentes pc);
}
