import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Tipo de usuario
        System.out.println("===========================================");
        System.out.println("           SIMULADOR DE ARMADO DE PC       ");
        System.out.println("===========================================\n");

        System.out.println("Elige el tipo de configuracion:");
        System.out.println("1. Gamer (15% descuento)");
        System.out.println("2. Estudiante (10% descuento)");
        System.out.print("Seleccion: ");

        int tipo = 0;
        while (tipo != 1 && tipo != 2) {
            if (scanner.hasNextInt()) {
                tipo = scanner.nextInt();
            } else {
                scanner.next();
            }
        }

        // Opciones por categoria
        List<Pieza> opcionesCPU = Arrays.asList(
                new Pieza("Ryzen 5 5600X", 4200),
                new Pieza("Intel i5 12400F", 4100),
                new Pieza("Ryzen 7 5800X", 5600)
        );

        List<Pieza> opcionesGPU = Arrays.asList(
                new Pieza("RTX 4060", 8800),
                new Pieza("RX 7600", 7600),
                new Pieza("RTX 4070", 11900)
        );

        List<Pieza> opcionesRAM = Arrays.asList(
                new Pieza("Corsair 16GB", 1600),
                new Pieza("Kingston 16GB", 1500),
                new Pieza("G.Skill 32GB", 3200)
        );

        List<ComponentePC> opcionesAlmacenamiento = new ArrayList<>();
        opcionesAlmacenamiento.add(new Pieza("SSD 1TB", 1400));
        opcionesAlmacenamiento.add(new Pieza("HDD 2TB", 1000));

        CategoriaComponentes combo = new CategoriaComponentes("Combo SSD + HDD");
        combo.agregar(new Pieza("SSD 1TB", 1400));
        combo.agregar(new Pieza("HDD 2TB", 1000));

        ComponentePC comboConDescuento = new ComponentePC() {
            @Override
            public void mostrar() {
                System.out.println("  - Combo SSD + HDD (con descuento):");
                combo.mostrar();
            }

            @Override
            public double obtenerPrecio() {
                return combo.obtenerPrecio() * 0.90;
            }

            @Override
            public String toString() {
                return "Combo SSD + HDD ($" + obtenerPrecio() + ")";
            }
        };
        opcionesAlmacenamiento.add(comboConDescuento);

        List<Pieza> opcionesRefrigeracion = Arrays.asList(
                new Pieza("Refrigeracion por aire", 800),
                new Pieza("Refrigeracion liquida", 1800)
        );

        List<Pieza> opcionesFuente = Arrays.asList(
                new Pieza("Fuente 550W", 900),
                new Pieza("Fuente 750W", 1200),
                new Pieza("Fuente 850W Modular", 1600)
        );

        // Armar PC
        // Estructura jerárquica usando el patrón Composite
        CategoriaComponentes pc = new CategoriaComponentes("PC Armado");

        pc.agregar(seleccionarPieza("CPU", opcionesCPU, scanner));
        pc.agregar(seleccionarPieza("GPU", opcionesGPU, scanner));
        pc.agregar(seleccionarPieza("RAM", opcionesRAM, scanner));
        pc.agregar(seleccionarComponente("Almacenamiento", opcionesAlmacenamiento, scanner));
        pc.agregar(seleccionarPieza("Refrigeracion", opcionesRefrigeracion, scanner));
        pc.agregar(seleccionarPieza("Fuente de poder", opcionesFuente, scanner));

        // Mostrar PC armada
        System.out.println("\n===========================================");
        System.out.println("       CONFIGURACION FINAL DE TU PC        ");
        System.out.println("===========================================");
        pc.mostrar();

        // Calcular subtotal
        double subtotal = pc.obtenerPrecio();
        System.out.println("\nSubtotal: $" + subtotal);

        // Aplicar estrategia de precio segun tipo
        CalculadoraPrecio calc;
        if (tipo == 1) {
            calc = new CalculadoraPrecio(new PrecioDescuentoGamer());
            System.out.println("Se aplico descuento Gamer del 15%");
        } else {
            calc = new CalculadoraPrecio(new PrecioEstudiante());
            System.out.println("Se aplico descuento Estudiante del 10%");
        }

        System.out.println("Total con descuento: $" + calc.calcularPrecio(pc));
    }

    // Metodo para seleccionar una pieza simple (CPU, GPU, etc.)
    public static Pieza seleccionarPieza(String tipo, List<Pieza> opciones, Scanner scanner) {
        System.out.println("\nSelecciona una opcion para " + tipo + ":");
        for (int i = 0; i < opciones.size(); i++) {
            System.out.println((i + 1) + ". " + opciones.get(i));
        }

        int seleccion = -1;
        while (seleccion < 1 || seleccion > opciones.size()) {
            System.out.print("Opcion (1-" + opciones.size() + "): ");
            if (scanner.hasNextInt()) {
                seleccion = scanner.nextInt();
            } else {
                scanner.next();
            }
        }

        System.out.println("Seleccionado: " + opciones.get(seleccion - 1));
        return opciones.get(seleccion - 1);
    }

    // Metodo para seleccionar un componente que puede ser hoja o compuesto
    public static ComponentePC seleccionarComponente(String tipo, List<ComponentePC> opciones, Scanner scanner) {
        System.out.println("\nSelecciona una opcion para " + tipo + ":");
        for (int i = 0; i < opciones.size(); i++) {
            System.out.println((i + 1) + ". " + opciones.get(i).toString());
        }

        int seleccion = -1;
        while (seleccion < 1 || seleccion > opciones.size()) {
            System.out.print("Opcion (1-" + opciones.size() + "): ");
            if (scanner.hasNextInt()) {
                seleccion = scanner.nextInt();
            } else {
                scanner.next();
            }
        }

        System.out.println("Seleccionado: " + opciones.get(seleccion - 1).toString());
        return opciones.get(seleccion - 1);
    }
}


