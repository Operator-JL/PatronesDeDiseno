// Clase hoja que representa una pieza individual
public class Pieza implements ComponentePC {
    private String nombre;
    private double precio;

    public Pieza(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    @Override
    public void mostrar() {
        System.out.println("  - " + nombre + ": $" + precio);
    }

    @Override
    public double obtenerPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return nombre + " ($" + precio + ")";
    }
}
