// Estrategia de precio con descuento gamer (15 porciento)
public class PrecioDescuentoGamer implements EstrategiaPrecio {
    @Override
    public double calcular(CategoriaComponentes pc) {
        return pc.obtenerPrecio() * 0.85;
    }
}
