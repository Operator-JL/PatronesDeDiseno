// Estrategia de precio con descuento estudiante (10 porciento)
public class PrecioEstudiante implements EstrategiaPrecio {
    @Override
    public double calcular(CategoriaComponentes pc) {
        return pc.obtenerPrecio() * 0.90;
    }
}
