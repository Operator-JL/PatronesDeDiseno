// Estrategia de precio sin descuento
public class PrecioNormal implements EstrategiaPrecio {
    @Override
    public double calcular(CategoriaComponentes pc) {
        return pc.obtenerPrecio();
    }
}
